# Uber Interview Material

The files contained here are my solutions to Uber's data exercise.  The data challenge was part of my interview with them for a Data Scientist position in 2017. For an explanation of Uber's interview process as well as my solutions to the data exercise, please check out: [ryanpmccaffrey.github.io](https://ryanpmccaffrey.github.io/2017-12-02-Uber-Data-Challenge/)
